package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import pl.droidsonroids.gif.GifImageView;

/**
 * Esta clase es la actividad que se muestra cuando el usuario pierde el juego
 */
public class MainActivity3 extends AppCompatActivity {

    GifImageView dead;
    Button home;

/**
 * Crea un botón que te lleva de vuelta a la página de inicio.
 * 
 * @param savedInstanceState Un objeto Bundle que contiene el estado guardado previamente de la
 * actividad. Si la actividad nunca ha existido antes, el valor del objeto Bundle es nulo.
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        dead = findViewById(R.id.dead);
        home = findViewById(R.id.home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

}