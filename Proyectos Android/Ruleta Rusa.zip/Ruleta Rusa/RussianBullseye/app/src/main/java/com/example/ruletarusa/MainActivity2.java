package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import pl.droidsonroids.gif.GifImageView;

/**
 * Es una clase que extiende AppCompatActivity y tiene un GifImageView y un Button
 */
public class MainActivity2 extends AppCompatActivity {

// declarando variables
    GifImageView alive;
    Button retry;

/**
 * La función onCreate que se llama cuando se crea la actividad.
 * 
 * @param savedInstanceState Un objeto Bundle que contiene el estado guardado previamente de la
 * actividad. Si la actividad nunca ha existido antes, el valor del objeto Bundle es nulo.
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        alive = findViewById(R.id.alive);
        retry = findViewById(R.id.retry);

        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }




}