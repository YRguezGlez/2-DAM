package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

/**
 * Esta clase es la actividad principal de la aplicación, contiene los botones de entrada salida y la vista de imagen.
 */
public class MainActivity extends AppCompatActivity {

// Declaración de variables.
    ImageView silueta;
    Button shoot;
    Button giveup;

/**
 * Crea los botones y la imagen.
 * 
 * @param savedInstanceState Un objeto Bundle que contiene el estado guardado previamente de la
 * actividad. Si la actividad nunca ha existido antes, el valor del objeto Bundle es nulo.
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        silueta = findViewById(R.id.silueta);
        shoot = findViewById(R.id.shoot);
        giveup = findViewById(R.id.giveup);

// Creación de una nueva actividad.
        giveup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

// Creación de una nueva actividad.
        shoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                Intent i = new Intent(MainActivity.this,Diana.class);
                startActivity(i);
            }
        });
    }
}