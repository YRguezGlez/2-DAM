package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import pl.droidsonroids.gif.GifImageButton;

/**
 * Esta clase es la actividad principal del juego. Contiene la lógica del juego y las animaciones.
 */
public class Diana extends AppCompatActivity {

// Declaración de variables.
    ImageView diana;
    TextView texto;
    ImageView flecha1;
    ImageView flecha2;
    ImageView flecha3;
    ImageView flecha4;
    ImageView flecha5;
    GifImageButton disparar;
    int shots = 1;


/**
 * Crea la actividad y establece la vista de contenido en el archivo activity_diana.xml.
 * 
 * @param savedInstanceState Un objeto Bundle que contiene el estado guardado previamente de la
 * actividad. Si la actividad nunca ha existido antes, el valor del objeto Bundle es nulo.
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diana);

        diana = findViewById(R.id.diana);
        rotarDiana(diana);
        texto = findViewById(R.id.texto);
        flecha1 = findViewById(R.id.flecha1);
        flecha2 = findViewById(R.id.flecha2);
        flecha3 = findViewById(R.id.flecha3);
        flecha4 = findViewById(R.id.flecha4);
        flecha5 = findViewById(R.id.flecha5);
        flecha5.setVisibility(View.INVISIBLE);
        disparar = findViewById(R.id.disparar);
        dispararFlecha();

    }

/**
 * "Gire la vista 360 grados alrededor de su centro y repita la animación para siempre".
 * 
 * Los dos primeros parámetros del constructor RotateAnimation especifican los ángulos inicial y final
 * de la rotación. Los siguientes dos parámetros especifican el punto de pivote de la rotación. En este
 * caso, estamos rotando alrededor del centro de la vista.
 * 
 * @param view La vista para animar.
 */
    private void rotarDiana(View view) {
        RotateAnimation animation = new RotateAnimation(0, 360,
                RotateAnimation.RELATIVE_TO_SELF, 0.25f,
                RotateAnimation.RELATIVE_TO_SELF, 0.25f);

        animation.setDuration(2000);
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);
        view.startAnimation(animation);
    }

/**
 * Es una instrucción switch que verifica el valor de la variable tiros y dependiendo del valor, hará
 * invisible la flecha correspondiente y luego llamará a la función suerte() para generar un número
 * aleatorio. Si el número es 1, el usuario gana, si no lo es, el usuario pierde
 */
    private void dispararFlecha() {

        diana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                switch (shots) {
                    case 1:

                        flecha1.setVisibility(View.INVISIBLE);
                        shots++;
                        int random = suerte();
                        String aux = String.valueOf(random);
                        //Toast.makeText(Diana.this, aux, Toast.LENGTH_SHORT).show();
                        if (random == 1) {
                            Intent in = new Intent(Diana.this, MainActivity3.class);
                            startActivity(in);
                        } else {
                            Intent intent = new Intent(Diana.this, MainActivity2.class);
                            startActivity(intent);
                        }
                        break;

                    case 2:

                        flecha2.setVisibility(View.INVISIBLE);
                        shots++;
                        int random2 = suerte();
                        String aux2 = String.valueOf(random2);
                        //Toast.makeText(Diana.this, aux2, Toast.LENGTH_SHORT).show();
                        if (random2 == 1) {
                            Intent in = new Intent(Diana.this, MainActivity3.class);
                            startActivity(in);
                        } else {
                            Intent intent = new Intent(Diana.this, MainActivity2.class);
                            startActivity(intent);
                        }
                        break;

                    case 3:

                        flecha4.setVisibility(View.INVISIBLE);
                        shots++;
                        int random3 = suerte();
                        String aux3 = String.valueOf(random3);
                        //Toast.makeText(Diana.this, aux3, Toast.LENGTH_SHORT).show();
                        if (random3 == 1) {

                            Intent in = new Intent(Diana.this, MainActivity3.class);
                            startActivity(in);

                        } else {
                            Intent intent = new Intent(Diana.this, MainActivity2.class);
                            startActivity(intent);
                        }
                        break;

                    case 4:

                        flecha3.setVisibility(View.INVISIBLE);
                        shots++;
                       int random4 = suerte();
                       String aux4 = String.valueOf(random4);

                        //Toast.makeText(Diana.this, aux4, Toast.LENGTH_SHORT).show();
                        if (random4 == 1) {
                            Intent in = new Intent(Diana.this, MainActivity3.class);
                            startActivity(in);



                        } else {
                            Intent intent = new Intent(Diana.this, MainActivity2.class);
                            startActivity(intent);

                            flecha5.setVisibility(View.VISIBLE);
                            texto.setText("Well... since I'm feeling generous today, I'll give you one last chance. Here's an extra arrow - Use it well!");
                        }
                        break;

                    case 5:
                        flecha5.setVisibility(View.INVISIBLE);


                             Intent in = new Intent(Diana.this, MainActivity3.class);
                             startActivity(in);
                    break;
                }
            }
        });
    }

/**
 * Devuelve un número aleatorio entre 1 y 3
 * 
 * @return El método devuelve un número aleatorio entre 1 y 3.
 */
    private static int suerte() {
        int ronda = (int) (Math.random()*3+1);
        return ronda;
    }
}