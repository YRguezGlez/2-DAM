package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import org.imaginativeworld.whynotimagecarousel.ImageCarousel;
import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;
import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    // Declaración de variables globales.
    ImageCarousel carousel;
    TypeWriter tw;
    Button filtar;
    ImageView volver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().hide();

        // Relación de los elementos empleados en la activity xml con las variables de Java.
        carousel = findViewById(R.id.carousel);
        tw = findViewById(R.id.typew);
        filtar = findViewById(R.id.next);
        volver = findViewById(R.id.volver);

        //Texto animado creado con la clase TypeWriter.
        tw.setText("Recuerdos 2022");
        tw.setCharacterDelay(150);
        tw.animateText("Recuerdos 2022");

        //Registrar el ciclo de vida.
        carousel.registerLifecycle(getLifecycle());

        // Añadir las imágenes con un pie de foto al carrusel.
        List<CarouselItem> list = new ArrayList<>();

        list.add(new CarouselItem(R.drawable.enero, "Enero"));
        list.add(new CarouselItem(R.drawable.febrero, "Febrero"));
        list.add(new CarouselItem(R.drawable.marzo, "Marzo"));
        list.add(new CarouselItem(R.drawable.abril, "Abril"));
        list.add(new CarouselItem(R.drawable.mayo, "Mayo"));
        list.add(new CarouselItem(R.drawable.junio, "Junio"));
        list.add(new CarouselItem(R.drawable.julio, "Julio"));
        list.add(new CarouselItem(R.drawable.agosto, "Agosto"));
        list.add(new CarouselItem(R.drawable.septiembre, "Septiembre"));
        list.add(new CarouselItem(R.drawable.octubre, "Octubre"));
        list.add(new CarouselItem(R.drawable.noviembre, "Noviembre"));
        list.add(new CarouselItem(R.drawable.diciembre, "Diciembre"));

        carousel.setData(list);


        // Creación de evento "OnClick" que abre la activity3 al  pulsar en el botón.
        filtar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inten = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(inten);
            }
        });

        // Creación de evento "OnClick" que vuelve a la actividad anterior al  pulsar en el botón.
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}