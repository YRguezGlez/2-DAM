package com.example.carrusel;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;

/**
 * Toma una cadena, establece el texto en una cadena vacía, y luego añade un carácter al texto cada
 * mDelay milisegundos
 */
public class TypeWriter extends androidx.appcompat.widget.AppCompatTextView {
    private CharSequence mText;
    private int mIndex;
    private long mDelay = 150; // en ms

    // Un constructor que toma un contexto y llama al constructor de la superclase.
    public TypeWriter(Context context) {
        super(context);
    }

    // Un constructor que toma un contexto y un conjunto de atributos.
    public TypeWriter(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    private final Handler mHandler = new Handler();

    // Un ejecutable que es llamado cada mDelay milisegundos. Establece el texto en los primeros mIndex caracteres de mText.
    // Luego incrementa mIndex y se llama a sí mismo de nuevo si mIndex es menor que la longitud de mText.
    private final Runnable characterAdder = new Runnable() {

        @Override
        public void run() {
            setText(mText.subSequence(0, mIndex++));

            if (mIndex <= mText.length()) {
                mHandler.postDelayed(characterAdder, mDelay);
            }
        }
    };

    /**
     * Toma una cadena, establece el texto en una cadena vacía, y luego añade un carácter al texto cada
     * mDelay milisegundos
     *
     * @param txt El texto a animar
     */
    public void animateText(CharSequence txt) {
        mText = txt;
        mIndex = 0;

        setText("");
        mHandler.removeCallbacks(characterAdder);
        mHandler.postDelayed(characterAdder, mDelay);
    }
    /**
     * Esta función establece el tiempo de escritura entre cada carácter que se muestra
     *
     * @param m El tiempo de escritura entre cada carácter.
     */
    public void setCharacterDelay(long m) {
        mDelay = m;
    }
}
