package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

  // Declaración de variables globales.
    Button entrar;
    Button salir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

      // Relación de los elementos empleados en la activity xml con las variables de Java.
        entrar = findViewById(R.id.entrar);
        salir = findViewById(R.id.salir);


      // Creación de evento "OnClick" que cambia de actividad al  pulsar en el botón.
        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        // Creación de evento "OnClick" que cierra la aplicación al  pulsar en el botón.
        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}