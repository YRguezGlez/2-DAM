package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    // Declaración de variables globales.
    Spinner spinner;
    ImageView image;
    Button volver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        getSupportActionBar().hide();
        // Relación de los elementos empleados en la activity xml con las variables de Java.
        spinner = findViewById(R.id.spinner);
        image = findViewById(R.id.image);
        volver = findViewById(R.id.volver);

        // Crea un ArrayAdapter usando el array de cadenas y un diseño de spinner por defecto
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.images, android.R.layout.simple_spinner_item);
        // Especifica el diseño que se utilizará cuando aparezca la lista de opcionesr
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Aplicar el adapter al spinner.
        spinner.setAdapter(adapter);
        /*
          Cuando el usuario selecciona un elemento del spinner, la imagen predeterminada cambiará a la imagen correspondiente.

          @param adapterView La AdapterView donde ocurrió la selección
         * @param view La vista dentro del AdapterView en la que se hizo clic (será una vista proporcionada por el adaptador)
         * @param i La posición del elemento seleccionado en el adaptador.
         * @param l long
         * */

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        image.setImageResource(R.drawable.enero);
                        Toast.makeText(MainActivity3.this, "Enero", Toast.LENGTH_SHORT).show();
                    break;
                    case 1:
                        image.setImageResource(R.drawable.febrero);
                        Toast.makeText(MainActivity3.this, "Febrero", Toast.LENGTH_SHORT).show();
                    break;
                    case 2:
                        image.setImageResource(R.drawable.marzo);
                        Toast.makeText(MainActivity3.this, "Marzo", Toast.LENGTH_SHORT).show();
                    break;
                    case 3:
                        image.setImageResource(R.drawable.abril);
                        Toast.makeText(MainActivity3.this, "Abril", Toast.LENGTH_SHORT).show();
                    break;
                    case 4:
                        image.setImageResource(R.drawable.mayo);
                        Toast.makeText(MainActivity3.this, "Mayo", Toast.LENGTH_SHORT).show();
                    break;
                    case 5:
                        image.setImageResource(R.drawable.junio);
                        Toast.makeText(MainActivity3.this, "Junio", Toast.LENGTH_SHORT).show();
                    break;
                    case 6:
                        image.setImageResource(R.drawable.julio);
                        Toast.makeText(MainActivity3.this, "Julio", Toast.LENGTH_SHORT).show();
                    break;
                    case 7:
                        image.setImageResource(R.drawable.agosto);
                        Toast.makeText(MainActivity3.this, "Agosto", Toast.LENGTH_SHORT).show();
                    break;
                    case 8:
                        image.setImageResource(R.drawable.septiembre);
                        Toast.makeText(MainActivity3.this, "Septiembre", Toast.LENGTH_SHORT).show();
                    break;
                    case 9:
                        image.setImageResource(R.drawable.octubre);
                        Toast.makeText(MainActivity3.this, "Octubre", Toast.LENGTH_SHORT).show();
                    break;
                    case 10:
                        image.setImageResource(R.drawable.noviembre);
                        Toast.makeText(MainActivity3.this, "Noviembre", Toast.LENGTH_SHORT).show();
                    break;
                    case 11:
                        image.setImageResource(R.drawable.diciembre);
                        Toast.makeText(MainActivity3.this, "Diciembre", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            // Un método que se llama cuando el usuario no selecciona nada.
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // Creación de evento "OnClick" que vuelve a la actividad anterior al  pulsar en el botón.
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}