# Importación de los módulos necesarios para la ejecución del programa.
from tkinter.simpledialog import askstring
import xml.etree.ElementTree as ET
import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter import scrolledtext
from tkinter import Button
from tkinter import PhotoImage
from tkinter.filedialog import askopenfilename


# Crear una ventana y configurar el título, el tamaño, el fondo y abrir un archivo.

filename = askopenfilename(title='Seleccione un archivo')
tree = ET.parse(filename)
root = tree.getroot()


#Opción de crear una audioteca.
def CrearAudioteca():
    
# Crear un nuevo archivo XML con el nombre de la cadena ingresada por el usuario.
    audioteca = askstring('Nombre archivo', 'Introduzca el nombre de la nueva audioteca: ')
    discos = ET.Element("discos")
    arbol = ET.ElementTree(discos)
    arbol.write(audioteca + ".xml")
    

# Creando una nueva ventana y agregandole algunos widgets.
    crear_audioteca = tk.Toplevel()
    crear_audioteca.title('Introducción de un nuevo álbúm')
    crear_audioteca.resizable(True, True)
    crear_audioteca.config(cursor="pencil")

# Crear una ventana con los campos de entrada necesarios.
    disco = Label(master=crear_audioteca, text="Título del álbum: ")
    disco.pack()
    titulo_disco = tk.Entry(crear_audioteca , width=50)
    titulo_disco.pack(pady=5)

    artista = Label(master=crear_audioteca, text="Nombre del artista(s): ")
    artista.pack()
    nombre_artista = tk.Entry(crear_audioteca, width=50)
    nombre_artista.pack(pady=5)

    genero = Label(master=crear_audioteca, text="Género:")
    genero.pack()
    genero_disco = tk.Entry(crear_audioteca, width=50)
    genero_disco.pack(pady=5)

    anio = Label(master=crear_audioteca, text="Año del publicación: ")
    anio.pack()
    anio_disco= tk.Entry(crear_audioteca, width=50)
    anio_disco.pack(pady=5)

    nombre = Label(master=crear_audioteca, text="Nombre de canción: ")
    nombre.pack(pady=5)
    nombre_cancion = tk.Entry(crear_audioteca, width=50)
    nombre_cancion.pack()

    duracion = Label(master=crear_audioteca, text="Duración de canción: ")
    duracion.pack()
    duracion_cancion = tk.Entry(crear_audioteca, width=50)
    duracion_cancion.pack(pady=5)
    canciones = scrolledtext.ScrolledText(crear_audioteca)
    canciones.pack(pady=5)

    def AniadirCancion():
        
    # Agrega el nombre de la canción y la duración al cuadro de lista.
        
        canciones.config(state=NORMAL)
        canciones.insert(END, '\'' + nombre_cancion.get() + '\'')
        canciones.insert(END, '\''+ duracion_cancion.get() + '\'' + "\n")
        canciones.config(state=DISABLED)

    def BorrarCancion():
        
    # Elimina la última canción en el cuadro de lista.

        aux = int(canciones.index('end').split('.')[0]) - 2
        aux = aux + .0
        canciones.config(state=NORMAL)
        canciones.delete(aux, END)
        canciones.config(state=DISABLED)

    def GuardarDisco():

    # Crea un nuevo archivo XML con la información que el usuario ha ingresado.
        disco = ET.SubElement(discos, 'Álbum ', titulo=titulo_disco.get(), artista=nombre_artista.get(), genero=genero_disco.get(), anho=anio_disco.get())
        aux = int(canciones.index('end').split('.')[0]) - 2
        
        cont_linea = 0
        for line in range(1, aux+1):
            cont_linea = cont_linea + 1 
            cont_coma = 0
            index_cuarta_coma = 0
            index_segunda_coma = 0
            str_aux = canciones.get(cont_linea + .0, END)
            
            i = 0
            while i < len(str_aux):
                if(str_aux[i].__eq__ ('\'')):
                    cont_coma = cont_coma + 1
                if(cont_coma == 2):
                    index_segunda_coma = i + 1
                if(cont_coma == 5):
                    index_cuarta_coma = i + 1
                    break
                i+=1
             
            nombre_aux = str_aux[1:index_segunda_coma - 1]
            duracion_aux = str_aux[index_segunda_coma + 1 :index_cuarta_coma - 1]
            print(nombre_aux)
            print(duracion_aux)
            cancion = ET.SubElement(disco,'Cancion', nombre=nombre_aux, duracion=duracion_aux)

        arbol.write(audioteca + ".xml")

# Crea una nueva ventana con algunos widgets.

    aniadir_cancion = Button(master=crear_audioteca, bg="medium purple", text="Añadir", compound="center", command=AniadirCancion)
    aniadir_cancion.pack(pady=5)
    borrar_cancion = Button(master=crear_audioteca, bg="medium purple", text="Borrar último dato introducido", compound="center", command=BorrarCancion)
    borrar_cancion.pack(pady=5)
    guardar_disco = Button(master=crear_audioteca, bg="medium purple", text="Guardar", compound="center", command=GuardarDisco)
    guardar_disco.pack(pady=5)

def SeleccionarAudioteca():

# Abre un cuadro de diálogo de archivo y luego muestra el nombre del archivo que se seleccionó mediante una ventana de mensaje.
    global filename, tree, root
    filename = askopenfilename(title='Seleccione un archivo')
    tree = ET.parse(filename)
    root = tree.getroot()
    tk.messagebox.showinfo(title=None, message='Archivo seleccionado: \n' + filename)

def MostrarDiscos():

# Lee el archivo XML y luego imprime el contenido del archivo XML en un widget de texto.

    string = ""
    chars='{},'

    #Recorremos el archivo xml guardando en string los elementos con sus atributos.
    for child in root: 
        string += "\n\n" + str(child.tag) + " " + str(child.attrib)
        for child in child:
            string += "\n" + str(child.tag) + " " + str(child.attrib)

    # Borra caracteres innecesarios de la cadena.
    string = string.translate(str.maketrans('', '', chars))
    string = string.replace('\'', ' ')
    # Reemplazamos el contenido anterior por la nueva cadena resultante.
    st.config(state=NORMAL)
    st.replace('1.0', END, string)
    st.config(state=DISABLED)

def ModificarAudioteca():

    nom_alb = askstring('Edición', 'Introduzca el título del álbum a modificar: ')
    # Creando una nueva ventanay agregarle algunos widgets.
    mod_aud = tk.Toplevel()
    mod_aud.title('Inserción de nuevo álbum')
    mod_aud.resizable(True, True)
    mod_aud.config(cursor="pencil")

    # Creando una nueva ventana con la información del álbum que el usuario quiere modificar.
    for child in root:
        if child.attrib['titulo'] == nom_alb:
            modificar_disco = tk.Toplevel()
            modificar_disco.title('Modificar álbum existente')
            modificar_disco.resizable(True, True)

            disco = Label(master=modificar_disco, text="Título del álbum: ")
            disco.pack()
            nombre_disco = tk.Entry(modificar_disco , width=50)
            nombre_disco.insert(0, child.attrib['titulo'])
            nombre_disco.pack(pady=5)

            artista = Label(master=modificar_disco, text="Nombre del artista(s): ")
            artista.pack()
            nombre_artista = tk.Entry(modificar_disco, width=50)
            nombre_artista.insert(0, child.attrib['artista'])
            nombre_artista.pack(pady=5)

            genero = Label(master=modificar_disco, text="Género:")
            genero.pack()
            genero_disco = tk.Entry(modificar_disco, width=50)
            genero_disco.insert(0, child.attrib['genero'])
            genero_disco.pack(pady=5)

            anio = Label(master=modificar_disco, text="Año del publicacion: ")
            anio.pack()
            anio_disco= tk.Entry(modificar_disco, width=50)
            anio_disco.insert(0, child.attrib['anho'])
            anio_disco.pack(pady=5)

            nombre = Label(master=modificar_disco, text="Nombre de canción: ")
            nombre.pack()
            nombre_cancion = tk.Entry(modificar_disco, width=50)
            nombre_cancion.pack(pady=5)

            duracion = Label(master=modificar_disco, text="Duración de canción: ")
            duracion.pack()
            duracion_cancion = tk.Entry(modificar_disco, width=50)
            duracion_cancion.pack(pady=5)

            canciones = scrolledtext.ScrolledText(modificar_disco)
            canciones.pack(pady=5)
            
            for child2 in child:
                canciones.insert(END, '\n\'' + child2.attrib['titulo'] + '\'')
                canciones.insert(END, '\''+ child2.attrib['duracion'] + '\'')
            
            def AniadirCancion():
                canciones.config(state=NORMAL)
                canciones.insert(END, '\n\'' + nombre_cancion.get() + '\'')
                canciones.insert(END, '\''+ duracion_cancion.get() + '\'')
                canciones.config(state=DISABLED)

            def BorrarCancion():
                aux = float(canciones.index('end')) - 1
                canciones.config(state=NORMAL)
                canciones.delete(aux, END)
                canciones.config(state=DISABLED)

            def GuardarDisco():
                print()

            aniadir_cancion = Button(master=modificar_disco, bg="medium purple", text="Añadir", compound="center", command=AniadirCancion)
            aniadir_cancion.pack(pady=5)
            borrar_cancion = Button(master=modificar_disco, bg="medium purple", text="Borrar", compound="center", command=BorrarCancion)
            borrar_cancion.pack(pady=5)
            guardar_disco = Button(master=modificar_disco, bg="medium purple", text="Guardar", compound="center", command=GuardarDisco)
            guardar_disco.pack(pady=5)
            break



# Crear una ventana y configurar el título, tamaño, fondo para abrir un archivo.
app = Tk()
app.title('Universol Audioteca')
app.resizable(True, True)
app.config(cursor="pencil")
app.configure(background="lavender")

Tk().withdraw()

# Creación de un botón con una imagen.
Albums = PhotoImage()
Albums.configure(file='Recursos\\biblioteca.png')
Playlist = PhotoImage()
Playlist.configure(file='Recursos\\playlist.png')
Cambiar = PhotoImage()
Cambiar.configure(file='Recursos\\cambiar.png')
Musica = PhotoImage()
Musica.configure(file='Recursos\\musica.png')
crear_audioteca = Button(master=app, text="Crear nueva audioteca", font=64, image=Playlist, compound="left", command=CrearAudioteca, bg="medium purple")
crear_audioteca.pack(pady=10)

seleccionar_audioteca = Button(master=app, text="Seleccionar otra audioteca", font=64, image=Cambiar, compound="left", command=SeleccionarAudioteca, bg="medium purple")
seleccionar_audioteca.pack(pady=10)

mostrardiscos = Button(master=app, text="Mostrar discos", font=64, image=Albums, compound="left", command=MostrarDiscos, bg="medium purple")
mostrardiscos.pack(pady=10)

modificardisco = Button(master=app, text="Modificar audioteca", font=64, image=Musica, compound="left", command=ModificarAudioteca, bg="medium purple")
modificardisco.pack(pady=10)

# Creación de un widget de texto desplazable (scrollbar).
st = scrolledtext.ScrolledText(app)
st.pack()

# Un método que se utiliza para ejecutar la aplicación.
app.mainloop()