package com.example.prueba_proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.prueba_proyecto.adapters.BillboardRecycler;
import com.example.prueba_proyecto.adapters.RecyclerViewAdapter;
import com.example.prueba_proyecto.models.AllCategory;
import com.example.prueba_proyecto.models.CategoryItem;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Billboard extends AppCompatActivity {

    RecyclerView CategoryRecycler;
    BillboardRecycler billboardRecyclerAdapter;
    ImageView back;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billboard);

        // here we will add some dummy data to our model class

        // here we will add data to category item model class

        // added in first category
        ArrayList<CategoryItem> categoryItemList = new ArrayList<>();
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));
        categoryItemList.add(new CategoryItem(1, R.drawable.category1));

        // added in second category
        List<CategoryItem> categoryItemList2 = new ArrayList<>();
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));
        categoryItemList2.add(new CategoryItem(1, R.drawable.category2));

        // added in 3rd category
        List<CategoryItem> categoryItemList3 = new ArrayList<>();
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));
        categoryItemList3.add(new CategoryItem(1, R.drawable.category3));

        // added in 4th category
        List<CategoryItem> categoryItemList4 = new ArrayList<>();
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));
        categoryItemList4.add(new CategoryItem(1, R.drawable.series));


        // added in 5th category
        List<CategoryItem> categoryItemList5 = new ArrayList<>();
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        categoryItemList5.add(new CategoryItem(1, R.drawable.pelis));
        List<AllCategory> allCategoryList = new ArrayList<>();
        allCategoryList.add(new AllCategory(getString(R.string.continue_view), categoryItemList));
        allCategoryList.add(new AllCategory(getString(R.string.popular), categoryItemList2));
        allCategoryList.add(new AllCategory(getString(R.string.trend), categoryItemList3));
        allCategoryList.add(new AllCategory(getString(R.string.series), categoryItemList4));
        allCategoryList.add(new AllCategory(getString(R.string.movies), categoryItemList5));

        setMainCategoryRecycler(allCategoryList);


        back = findViewById(R.id.back_btn);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Billboard.this, MainPage.class);
                startActivity(intent);
            }
        });


    }



    private void setMainCategoryRecycler(List<AllCategory> allCategoryList){

        CategoryRecycler = findViewById(R.id.billboard_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        CategoryRecycler.setLayoutManager(layoutManager);
        billboardRecyclerAdapter = new BillboardRecycler(this, allCategoryList);
        CategoryRecycler.setAdapter(billboardRecyclerAdapter);


    }
}