package com.example.prueba_proyecto.adapters;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.prueba_proyecto.R;
import com.example.prueba_proyecto.dbManager;
import com.example.prueba_proyecto.models.Model;

import java.util.ArrayList;

public class myAdapter extends RecyclerView.Adapter<myAdapter.myviewholder> {
    ArrayList<Model> dataholder =  new ArrayList<Model>();
    View view;

    public myAdapter(ArrayList<Model> dataholder) {
        this.dataholder = dataholder;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R .layout.item_task, parent, false);  //inflates the xml file in recyclerview
        return new myviewholder(view);
    }

        @Override
        public void onBindViewHolder(@NonNull myviewholder holder, int position) {
            //Binds the single reminder objects to recycler view
            holder.mTitle.setText(dataholder.get(position).getTitle());
            holder.mContent.setText(dataholder.get(position).getContent());
            holder.mDate.setText(dataholder.get(position).getDate());
            holder.mTime.setText(dataholder.get(position).getTime());
        }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }


    class myviewholder extends RecyclerView.ViewHolder {

        TextView mTitle, mContent, mDate, mTime;

        public myviewholder(@NonNull View itemView) {
            super(itemView);

            mTitle = itemView.findViewById(R.id.txtTitle);
            mContent = itemView.findViewById(R.id.txtContent);
            //holds the reference of the materials to show data in recyclerview
            mDate = itemView.findViewById(R.id.txtDate);
            mTime = itemView.findViewById(R.id.txtTime);
        }
    }
}
