package com.example.prueba_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Profile extends AppCompatActivity {

    TextView t_user, t_email, t_pass;
    ImageView settings;
    ImageView home;
    TextView wishlist, calendar;
    FirebaseFirestore db;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        db = FirebaseFirestore.getInstance();

        auth = FirebaseAuth.getInstance();

        t_user = findViewById(R.id.tv_name);

        t_email = findViewById(R.id.t_email);

        t_pass = findViewById(R.id.t_pass);

        settings = findViewById(R.id.ic_settings);

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Settings.class);
                startActivity(intent);
            }
        });

        home = findViewById(R.id.ic_home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, MainPage.class);
                startActivity(intent);
            }
        });

        wishlist = findViewById(R.id.w_link);

        wishlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Wishlist.class);
                startActivity(intent);
            }
        });

        calendar = findViewById(R.id.c_link);

        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Calendar.class);
                startActivity(intent);
            }
        });

        obtainUser();

    }

    private void obtainUser() {
        String id = auth.getCurrentUser().getUid();
        db.collection("user").document(id).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (documentSnapshot.exists()){
                    String user = documentSnapshot.getString("name");
                    String email = documentSnapshot.getString("email");
                    String pass = documentSnapshot.getString("password");

                    t_user.setText(getString(R.string.hi) + user);
                    t_email.setText(email);
                    t_pass.setText(pass);
                }
            }
        });
    }
}