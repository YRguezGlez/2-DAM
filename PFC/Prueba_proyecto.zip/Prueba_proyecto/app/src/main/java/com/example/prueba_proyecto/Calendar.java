package com.example.prueba_proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.prueba_proyecto.adapters.myAdapter;
import com.example.prueba_proyecto.models.Model;
import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Calendar extends AppCompatActivity {

    com.getbase.floatingactionbutton.FloatingActionButton mCreateRem, mDeleteRem;
    com.getbase.floatingactionbutton.FloatingActionsMenu floatingActionsMenu;
    RecyclerView mRecyclerview;
    ArrayList<Model> dataholder = new ArrayList<Model>();
    //Array list to add reminders and display in recyclerview
    myAdapter adapter;

    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        mRecyclerview = findViewById(R.id.recyclerView);
        mRecyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        floatingActionsMenu = findViewById(R.id.menu_reminder);
        mCreateRem = findViewById(R.id.add);

        //Floating action button to change activity
        mCreateRem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Starts the new activity to add Reminders
                Intent intent = new Intent(getApplicationContext(), AlarmActivity.class);
                startActivity(intent);
            }
        });

        Cursor cursor = new dbManager(getApplicationContext()).readallreminders();                  //Cursor To Load data From the database
        while (cursor.moveToNext()) {
            Model model = new Model(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
            dataholder.add(model);
        }

        adapter = new myAdapter(dataholder);
        mRecyclerview.setAdapter(adapter);

        //Binds the adapter with recyclerview
        // Set the long click listener on the adapter




        back = findViewById(R.id.back_btn);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Calendar.this, MainPage.class);
                startActivity(intent);
            }
        });
    }
        @Override
        public void onBackPressed() {
            finish();                                                                                   //Makes the user to exit from the app
            super.onBackPressed();

        }

   }
