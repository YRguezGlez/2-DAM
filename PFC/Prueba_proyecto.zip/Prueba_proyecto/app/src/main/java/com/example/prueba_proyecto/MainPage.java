package com.example.prueba_proyecto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.Timer;
import java.util.TimerTask;

public class MainPage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    Timer timer;

    /**
     * Crea el cajón de navegación y la barra de herramientas.
     *
     * @param savedInstanceState Este es un objeto Bundle que contiene el estado guardado previamente de la
     * actividad. Si la actividad nunca ha existido antes, el valor del objeto Bundle es nulo.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        timer = new Timer();

        drawerLayout = findViewById(R.id.main_page);
        NavigationView navigationView = findViewById(R.id.n_view);

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_home);
        }

    }

    /**
     * Es un interruptor que verifica la identificación del elemento seleccionado en el cajón de navegación
     * y luego abre la actividad o fragmento correspondiente
     *
     * @param item El elemento del menú que se seleccionó.
     * @return El método devuelve un valor booleano.
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                break;

            case R.id.nav_billboard:
                Intent intent_b = new Intent(MainPage.this, Billboard.class);
                startActivity(intent_b);
                break;

            case R.id.nav_wishlist:
                Intent intent_w = new Intent(MainPage.this, Wishlist.class);
                startActivity(intent_w);
                break;
            case R.id.nav_calendar:
                Intent intent_c  = new Intent(MainPage.this, Calendar.class);
                startActivity(intent_c);
                break;
            case R.id.nav_profile:
                Intent intent_p = new Intent(MainPage.this, Profile.class);
                startActivity(intent_p);
                break;
            case R.id.nav_settings:
                Intent intent_s = new Intent(MainPage.this, Settings.class);
                startActivity(intent_s);
                break;
            case R.id.nav_logout:
                Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        finishAffinity();
                    }
                }, 1500);
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

}