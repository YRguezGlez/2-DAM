package com.example.prueba_proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.prueba_proyecto.adapters.RecyclerViewAdapter;
import com.example.prueba_proyecto.models.Fav_content;

import java.util.ArrayList;
import java.util.List;

public class Wishlist extends AppCompatActivity {
    List<Fav_content> wishList ;
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        back = findViewById(R.id.back_btn);

        wishList = new ArrayList<>();
        wishList.add(new Fav_content(getString(R.string.movie),getString(R.string.category),getString(R.string.description),R.drawable.pelis));
        wishList.add(new Fav_content(getString(R.string.serie),getString(R.string.category),getString(R.string.description),R.drawable.series));
        wishList.add(new Fav_content(getString(R.string.reality),getString(R.string.category),getString(R.string.description),R.drawable.category1));
        wishList.add(new Fav_content(getString(R.string.documentary),getString(R.string.category),getString(R.string.description),R.drawable.category2));
        wishList.add(new Fav_content(getString(R.string.extras),getString(R.string.category),getString(R.string.description),R.drawable.category3));
        wishList.add(new Fav_content(getString(R.string.movie),getString(R.string.category),getString(R.string.description),R.drawable.pelis));
        wishList.add(new Fav_content(getString(R.string.serie),getString(R.string.category),getString(R.string.description),R.drawable.series));
        wishList.add(new Fav_content(getString(R.string.reality),getString(R.string.category),getString(R.string.description),R.drawable.category1));
        wishList.add(new Fav_content(getString(R.string.documentary),getString(R.string.category),getString(R.string.description),R.drawable.category2));
        wishList.add(new Fav_content(getString(R.string.extras),getString(R.string.category),getString(R.string.description),R.drawable.category3));
        wishList.add(new Fav_content(getString(R.string.movie),getString(R.string.category),getString(R.string.description),R.drawable.pelis));
        wishList.add(new Fav_content(getString(R.string.serie),getString(R.string.category),getString(R.string.description),R.drawable.series));
        wishList.add(new Fav_content(getString(R.string.reality),getString(R.string.category),getString(R.string.description),R.drawable.category1));
        wishList.add(new Fav_content(getString(R.string.documentary),getString(R.string.category),getString(R.string.description),R.drawable.category2));
        wishList.add(new Fav_content(getString(R.string.extras),getString(R.string.category),getString(R.string.description),R.drawable.category3));

        RecyclerView myrv = findViewById(R.id.recyclerview_id);
        RecyclerViewAdapter myAdapter = new RecyclerViewAdapter(this,wishList);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdapter);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Wishlist.this, MainPage.class);
                startActivity(intent);
            }
        });


    }
}
