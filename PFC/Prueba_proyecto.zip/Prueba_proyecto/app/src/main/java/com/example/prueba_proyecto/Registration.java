package com.example.prueba_proyecto;

import static android.content.ContentValues.TAG;
import static com.example.prueba_proyecto.R.drawable.baseline_error_24;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {
    private TextView enlace;
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private EditText e_u;
    private EditText e_e;
    private EditText e_p;
    private EditText e_rp;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        e_u = findViewById(R.id.username);
        e_e = findViewById(R.id.email);
        e_p = findViewById(R.id.pwd);
        e_rp = findViewById(R.id.pwd_2);
        btn = findViewById(R.id.btn_sign);
        enlace = findViewById(R.id.enlace);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = e_u.getText().toString().trim();
                String email = e_e.getText().toString().trim();
                String pass = e_p.getText().toString().trim();
                String confirm = e_rp.getText().toString().trim();

                if(user.isEmpty()){
                    e_u.setError("Username cannot be empty.", getResources().getDrawable(R.drawable.baseline_error_24));
                } else if (email.isEmpty()) {
                    e_e.setError("Email cannot be empty.", getResources().getDrawable(R.drawable.baseline_error_24));
                } else if (pass.isEmpty()) {
                    e_p.setError("Password cannot be empty.", getResources().getDrawable(R.drawable.baseline_error_24));
                } else if (confirm.isEmpty()) {
                    e_rp.setError("Please confirm password to enter the app.", getResources().getDrawable(R.drawable.baseline_error_24));
                } else if (!confirm.equals(pass)) {
                    e_rp.setError("The password you entered does not match. Please confirm password.", getResources().getDrawable(R.drawable.baseline_error_24));
                } else {
                    registerUser(user, email, pass);
                }
            }
        });

        enlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enlace.didTouchFocusSelect();
                Intent  intent = new Intent(Registration.this, Login.class);
                startActivity(intent);
            }
        });
    }

    private void registerUser(String user, String email, String pass) {
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                    String id = auth.getCurrentUser().getUid();

                    Map<String, Object> map = new HashMap<>();
                    map.put("id", id);
                    map.put("name", user);
                    map.put("email", email);
                    map.put("password", pass);

                    db.collection("user").document(id).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(Registration.this, "SignUp Successful", Toast.LENGTH_SHORT).show();
                            Intent  intent = new Intent(Registration.this, Login.class);
                            startActivity(intent);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Registration.this, "Error Saving User" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            Toast.makeText(Registration.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
            }
        });
    }


}